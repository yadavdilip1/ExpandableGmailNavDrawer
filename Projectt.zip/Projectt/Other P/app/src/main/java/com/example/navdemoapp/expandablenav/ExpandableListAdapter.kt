package com.example.navdemoapp.expandablenav

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.navdemoapp.R


internal class ExpandableListAdapter(
    context: Context, listHeader: List<HeaderModel>
) : BaseExpandableListAdapter() {
    private val context: Context
    private val listHeader: List<HeaderModel>

    init {
        this.context = context
        this.listHeader = listHeader
    }
    override fun getChild(groupPosition: Int, childPosititon: Int): Any {
        return listHeader[groupPosition].getChildModelList()[childPosititon]
    }

    override fun getChildId(groupPosition: Int, childPosition: Int): Long {
        return childPosition.toLong()
    }

    override fun getChildView(
        groupPosition: Int, childPosition: Int,
        isLastChild: Boolean, convertView: View?, parent: ViewGroup?
    ): View? {
        var convertView: View? = convertView
        val childText = getChild(groupPosition, childPosition) as ChildModel
        if (convertView == null) {
            val infalInflater = context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = infalInflater.inflate(R.layout.navigation_list_item, null)
        }
        val childMainLyt = convertView?.findViewById(R.id.childMainLyt) as ConstraintLayout
        val txtListChild = convertView?.findViewById(R.id.lblListItem) as TextView
        val iconMenu: ImageView = convertView?.findViewById(R.id.icon_menu)
        if (childText.resource != -1) iconMenu.setBackgroundResource(childText.resource)
        txtListChild.text = childText.title
        childMainLyt.isActivated = childText.isSelected
        return convertView
    }

    override fun getChildrenCount(groupPosition: Int): Int {
        return try {
            listHeader[groupPosition].getChildModelList().size
        } catch (e: Exception) {
            0
        }
    }

    override fun getGroup(groupPosition: Int): Any {
        return listHeader[groupPosition]
    }

    override fun getGroupCount(): Int {
        return listHeader.size
    }

    override fun getGroupId(groupPosition: Int): Long {
        return groupPosition.toLong()
    }

    override fun getGroupView(
        groupPosition: Int, isExpanded: Boolean,
        convertView: View?, parent: ViewGroup?
    ): View? {
        var convertView: View? = convertView
        val header = getGroup(groupPosition) as HeaderModel
        if (convertView == null) {
            val infalInflater = context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = infalInflater.inflate(R.layout.navigation_list_group, null)
        }
        val layoutGroup = convertView?.findViewById<ConstraintLayout>(R.id.layout_group)
        val lblListHeader = convertView?.findViewById(R.id.lblListHeader) as TextView
        val ivGroupIndicator: ImageView = convertView?.findViewById(R.id.ivGroupIndicator)
        val iconMenu: ImageView = convertView?.findViewById(R.id.icon_menu)
        val isNew: TextView = convertView?.findViewById(R.id.is_new)
        lblListHeader.text = header.title
        if (header.resource != -1) iconMenu.setBackgroundResource(header.resource)
        if (header.isHasChild) {
           // lblListHeader.setTypeface(null, Typeface.BOLD)
            ivGroupIndicator.setVisibility(View.VISIBLE)
            layoutGroup?.isActivated = false
            layoutGroup?.isSelected = header.isChecked

        } else {
            layoutGroup?.isSelected = false
            lblListHeader.setTypeface(null, Typeface.NORMAL)
            ivGroupIndicator.setVisibility(View.GONE)
            layoutGroup?.isActivated = header.isSelected
        }
        if (header.isNew) {
            isNew.visibility = View.VISIBLE
        } else {
            isNew.visibility = View.GONE
        }
        if (isExpanded) {
            ivGroupIndicator.setImageResource(R.drawable.ic_arrow_up)
        } else {
            ivGroupIndicator.setImageResource(R.drawable.ic_arrow_down)
        }
        return convertView
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun isChildSelectable(groupPosition: Int, childPosition: Int): Boolean {
        return true
    }


}
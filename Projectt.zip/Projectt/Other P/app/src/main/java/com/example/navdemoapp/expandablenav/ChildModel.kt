package com.example.navdemoapp.expandablenav

class ChildModel {
    var title: String
    var isSelected = false
    var resource = -1


    constructor(title: String, resource: Int) {
        this.title = title
        this.resource = resource

    }

    constructor(title: String, isSelected: Boolean) {
        this.title = title
        this.isSelected = isSelected
    }
}
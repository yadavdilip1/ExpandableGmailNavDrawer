package com.example.navdemoapp.expandablenav

class HeaderModel {
    var title: String
    var resource = -1
    var isNew = false
    var isHasChild = false
    var isSelected = false
    var isChecked = false
    var childModelList: ArrayList<ChildModel> = ArrayList()

    constructor(title: String) {
        this.title = title
    }

    constructor(title: String, resource: Int) {
        this.title = title
        this.resource = resource
    }

    constructor(title: String, resource: Int, hasChild: Boolean) {
        this.title = title
        this.resource = resource
        isHasChild = hasChild
    }

    constructor(
        title: String, resource: Int, hasChild: Boolean, isNew: Boolean, isSelected: Boolean
    ) {
        this.title = title
        this.resource = resource
        this.isNew = isNew
        isHasChild = hasChild
        this.isSelected = isSelected
    }

    fun addChildModel(childModel: ChildModel): HeaderModel {
        childModelList.add(childModel)
        return this
    }

    fun getChildModelList(): List<ChildModel> {
        return childModelList
    }

    fun setChildModelNavList(childModelList: ArrayList<ChildModel>) {
        this.childModelList = childModelList
    }
}
package com.example.navdemoapp

import android.os.Bundle
import android.view.Menu
import android.widget.ExpandableListView.OnChildClickListener
import android.widget.ExpandableListView.OnGroupClickListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.navdemoapp.databinding.ActivityMainBinding
import com.example.navdemoapp.expandablenav.ChildModel
import com.example.navdemoapp.expandablenav.ExpandableNavigationListView
import com.example.navdemoapp.expandablenav.HeaderModel
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    var listHeaderList: ArrayList<HeaderModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarMain.toolbar)

        binding.appBarMain.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        setNavData()

    }

    fun setNavData() {

        listHeaderList.add(HeaderModel("Beranda", R.drawable.ic_menu_gallery))
        listHeaderList.add(
            HeaderModel("Kotak Masuk1", R.drawable.ic_menu_gallery, true)
                .addChildModel(ChildModel("Chat", R.drawable.ic_menu_gallery))
                .addChildModel(ChildModel("Diskusi Produk", R.drawable.ic_menu_gallery))
        )
        listHeaderList.add(
            HeaderModel("Kotak Masuk1", R.drawable.ic_menu_gallery, true)
                .addChildModel(ChildModel("Chat", R.drawable.ic_menu_gallery))
                .addChildModel(ChildModel("Diskusi Produk", R.drawable.ic_menu_gallery))
        )
        listHeaderList.add(
            HeaderModel("Keluar4", R.drawable.ic_menu_gallery)
        )
        listHeaderList.add(
            HeaderModel("Keluar4", R.drawable.ic_menu_gallery)
        )


        val navigationExpandableListView =
            findViewById<ExpandableNavigationListView>(R.id.expandable_navigation)
        navigationExpandableListView
            .init(this)
            .setListMenu(listHeaderList)
            .build()
            .addOnGroupClickListener(OnGroupClickListener { parent, v, groupPosition, id ->

                if (!listHeaderList.isNullOrEmpty()) {

                    val headerModel = listHeaderList[groupPosition]
                    if (!headerModel.isHasChild) {
                        navigationExpandableListView.setSelected(groupPosition)
                        binding.drawerLayout.closeDrawer(GravityCompat.START)
                        Toast.makeText(this,headerModel.title,Toast.LENGTH_SHORT).show()

                    }
                }

                false
            })
            .addOnChildClickListener(OnChildClickListener { parent, v, groupPosition, childPosition, id ->
                if (!listHeaderList.isNullOrEmpty()) {

                    val childModel = listHeaderList[groupPosition].childModelList[childPosition]
                    navigationExpandableListView.setSelected(groupPosition, childPosition)
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                    Toast.makeText(this,childModel.title,Toast.LENGTH_SHORT).show()
                }
                false
            })

        navigationExpandableListView.setSelected(0)
        // navigationExpandableListView.setSelected(1,1)


    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}
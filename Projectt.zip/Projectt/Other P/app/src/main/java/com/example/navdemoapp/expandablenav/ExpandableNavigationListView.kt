package com.example.navdemoapp.expandablenav

import android.content.Context
import android.util.AttributeSet
import android.widget.ExpandableListView.OnChildClickListener

import android.widget.ExpandableListView.OnGroupClickListener

import android.view.ViewGroup

import android.view.View.MeasureSpec

import android.widget.ExpandableListView


class ExpandableNavigationListView : ExpandableListView {
    private var viewContext: Context? = null
    private var currentSelection = 0
    private var currentChildSelection = -1
    private var listHeader: MutableList<HeaderModel>? = null
    private var onGroupLytClickListener: OnGroupClickListener? = null
    private var onChildLytClickListener: OnChildClickListener? = null
    private var expandableListAdapter: ExpandableListAdapter? = null

    constructor(context: Context?) : super(context) {}
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {}
    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    ) {
    }

    public override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val heightMeasureSpec_custom = MeasureSpec.makeMeasureSpec(
            Int.MAX_VALUE shr 2, MeasureSpec.AT_MOST
        )
        super.onMeasure(widthMeasureSpec, heightMeasureSpec_custom)
        val params = layoutParams
        params.height = measuredHeight
    }

    fun init(context: Context?): ExpandableNavigationListView {
        this.viewContext = context
        listHeader = ArrayList()
        return this
    }

    fun setListMenu(listHeader: List<HeaderModel>?): ExpandableNavigationListView {
        if (listHeader != null) this.listHeader!!.addAll(listHeader)
        return this
    }

    fun addOnGroupClickListener(onGroupClickListener: OnGroupClickListener?): ExpandableNavigationListView {
        this.onGroupLytClickListener = onGroupClickListener
        setOnGroupClickListener(this.onGroupLytClickListener)
        return this
    }

    fun addOnChildClickListener(onChildClickListener: OnChildClickListener?): ExpandableNavigationListView {
        this.onChildLytClickListener = onChildClickListener
        setOnChildClickListener(this.onChildLytClickListener)
        return this
    }

    fun addHeaderModel(headerModel: HeaderModel): ExpandableNavigationListView {
        listHeader!!.add(headerModel)
        return this
    }

    fun build(): ExpandableNavigationListView {
        expandableListAdapter = ExpandableListAdapter(
            context,
            listHeader!!
        )
        setAdapter(expandableListAdapter)
        return this
    }

    fun setSelected(groupPosition: Int) {
        val headerModel = listHeader!![groupPosition]
        if (!headerModel.isHasChild) {
            val currentModel = listHeader!![currentSelection]
            currentModel.isSelected = false
            currentModel.isChecked = false

            if (currentChildSelection != -1) {
                val childModel = listHeader!![currentSelection]
                    .getChildModelList()[currentChildSelection]
                childModel.isSelected = false
                currentChildSelection = -1
            }
            headerModel.isSelected = true
            headerModel.isChecked = true
            currentSelection = groupPosition
            expandableListAdapter!!.notifyDataSetChanged()
        }
    }

    fun setSelected(groupPosition: Int, childPosition: Int) {
        val currentModel = listHeader!![currentSelection]
        currentModel.isSelected = false
        currentModel.isChecked = false

        if (currentChildSelection != -1) {
            val currentChildModel = listHeader!!
            .get(currentSelection)
                .getChildModelList()[currentChildSelection]
            currentChildModel.isSelected = false
        }
        currentSelection = groupPosition
        currentChildSelection = childPosition
        val childModel = listHeader!![groupPosition].getChildModelList()[childPosition]
        childModel.isSelected = true

        val headerModel = listHeader!![groupPosition]
        headerModel.isChecked = true

        expandableListAdapter!!.notifyDataSetChanged()
    }

}